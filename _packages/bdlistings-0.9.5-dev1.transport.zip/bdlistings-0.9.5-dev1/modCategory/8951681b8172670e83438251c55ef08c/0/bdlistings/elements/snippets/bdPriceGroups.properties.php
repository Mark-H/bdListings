<?php

return array(
    'limit' => 0,
    'start' => 0,
    'sortby' => 'sortorder',
    'sortdir' => 'ASC',

    'rowSeparator' => "\n",

    'tplOuter' => 'bdPriceGroups.outer',
    'tplRow' => 'bdPriceGroups.row',
);

?>
