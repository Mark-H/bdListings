+++++++++++++++++++++++++++++++++++
++                               ++
++   bdListings                  ++
++   Developer:  Mark Hamstra    ++
++   License:    GPL GNU v2      ++
++                               ++
+++++++++++++++++++++++++++++++++++

bdListings enables you to display (third party) listings for services, products, offers (ads).

There are no detail pages, however the link to the website (when set up properly) will be tracked and you can view the amount of clicks in a certain period through the back-end component.

It is possible to set up friendly URLs for the categories. See the documentation for more detailed information.

Documentation: 		http://rtfm.modx.com/display/ADDON/bdListings
Bugs & Features: 	https://github.com/Mark-H/bdListings/issues
Commercial Support:	hello@markhamstra.com
