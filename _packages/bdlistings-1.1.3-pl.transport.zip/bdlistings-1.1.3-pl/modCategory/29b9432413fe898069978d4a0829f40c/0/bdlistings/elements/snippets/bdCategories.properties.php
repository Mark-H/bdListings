<?php

return array(
    'limit' => 0,
    'offset' => 0,
    'sortby' => 'sortorder',
    'sortdir' => 'ASC',
    
    'parent' => 0,
    'includeSub' => true,
    'subSeparator' => ' - ',
    'categorySeparator' => "\n",

    'tplCategory' => 'bdCategories.category',
    'tplInner' => 'bdCategories.inner',
    'tplOuter' => 'bdCategories.outer',
    'tplSub' => 'bdCategories.subcategory',
);

?>
