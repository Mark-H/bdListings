+++++++++++++++++++++++++++++++++++
++                               ++
++   bdListings                  ++
++   Developer:  Mark Hamstra    ++
++   License:    GPL GNU v2      ++
++                               ++
+++++++++++++++++++++++++++++++++++


bdListings manages your listings


Documentation: 		http://rtfm.modx.com/display/ADDON/bdListings (coming soon)
Bugs & Features: 	https://github.com/Mark-H/bdListings/issues
Commercial Support:	hello@markhamstra.com